<?php
	header("Content-Type: text/html");
	require_once dirname(__FILE__) . '/vendor/AltoRouter/AltoRouter.php';

	$router = new AltoRouter();
	$router->setBasePath('');
	/* Setup the URL routing. This is production ready. */


	// Main routes that non-customers see
	$router->map('GET','/', 'index.html', 'index');
	$router->map('GET','/about', 'index.html', 'about');
	$router->map('GET','/publish-project', 'index.html', 'publish-project');
	$router->map('GET','/contacts', 'index.html', 'contacts');
	$router->map('GET','/for-advertisers', 'index.html', 'for-advertisers');
	$router->map('GET','/policy-personal-data', 'index.html', 'policy-personal-data');
	$router->map('GET','/privacy-policy', 'index.html', 'privacy-policy');
	$router->map('GET','/terms-of-use', 'index.html', 'terms-of-use');
	$router->map('GET','/page-not-found', 'index.html', 'page-not-found');


	// Special (scripts for get dates from DB)
	$router->map('GET','/last-articles/', 'last-articles/index.php', 'last-articles');
	$router->map('GET','/articles/', 'articles/index.php' , 'articles');
	$router->map('GET','/article/', 'article/index.php', 'article');
	$router->map('GET','/popular/', 'popular/index.php', 'popular');
	$router->map('GET','/last-rubric-article/', 'last-rubric-article/index.php', 'last-rubric-article');
	$router->map('GET','/last-rubric-article-list/', 'last-rubric-article-list/index.php', 'last-rubric-article-list');
	$router->map('GET','/rubric-articles/', 'rubric-articles/index.php', 'rubric-articles');


	// Special (pages with parametrs)
	$router->map('GET','/articles/[*:url]', 'index.html', 'articles-article');
	$router->map('GET','/rubrics/[*:id]','index.html', 'rubrics');
	$router->map('GET','/confirm-subscription/[*:id]','index.html', 'confirm-subscription');


	/* Match the current request */
	$match = $router->match();
	if($match) {
  	require $match['target'];
	} else {
  	header($_SERVER["SERVER_PROTOCOL"] . ' 404 Not Found');
  	header('Location: https://designtalk.ru/page-not-found');
	}
  
?>