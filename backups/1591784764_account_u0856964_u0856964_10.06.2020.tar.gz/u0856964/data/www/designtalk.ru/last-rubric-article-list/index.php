<?
  // shielding variables
  require_once './utils/shielding-variables.php';
  
	shieldingVariables();
  
  // get variables from the POST array
  extract($_GET);

	// connecting to db and get $link variable from them
  require_once './config/connect.php';
  
  
  // Fetching rubric data
  $rubric_data = mysqli_fetch_assoc(mysqli_query($link, "
    SELECT `id`, `link`, `name` 
    FROM `rubrics` 
    WHERE `id`='$rubric'
  "));
  
  if ($rubric_data) {
    
    // Fetching most popular articles from the rubric
  	$article_list = mysqli_query($link, "
			SELECT `article`, `rubric`, `visits` 
   		FROM `visits` 
  	  WHERE `rubric`='$rubric'
  	  ORDER BY `visits` DESC 
  	  LIMIT 4
  	" );
    
    if (mysqli_num_rows($article_list)) {
      
  		for($i = 0; $i < mysqli_num_rows($article_list); $i++) {
  		  $row = mysqli_fetch_row($article_list);
    
    
  		  // Fetching article data
  		  $article = mysqli_fetch_assoc(mysqli_query($link, "
  		  	SELECT `id`, `url`, `title`, `preview`, `picture`
  		  	FROM `articles` 
  		  	WHERE `id`='$row[0]'
  			"));

		
    		// Building the article and push it at the response array
				$response[] = array(
    		  'id' => $article['id'],
    		  'url' => $article['url'],
    		  'title' => $article['title'], 
    		  'preview' => $article['preview'],
    		  'picture' => $article['picture'],
	  		  'rubric' => array(
    		    'id' => $rubric_data['id'], 
    		    'link' => $rubric_data['link'], 
    		    'name' => $rubric_data['name']
    		  ),
    		  'visits' => $row[2],
					'visible' => false     
  		  );
  		}  
    } else $response = false;
  } else $response = false;
    
  
  echo json_encode($response);
  
?>