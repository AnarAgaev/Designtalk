<?
  // shielding variables
  require_once './utils/shielding-variables.php';
  
	shieldingVariables();
  
  // get variables from the POST array
  extract($_GET);
  
  // connecting to db and get $link variable from them
  require_once './config/connect.php';
  
  $rubric_data = mysqli_fetch_assoc(mysqli_query($link, "
  	SELECT 
    	`id`, 
      `link`, 
      `name` 
    FROM `rubrics` 
    WHERE `link`='$rubric'
  " ));
  
  if ($rubric_data) {
    
  	$article = mysqli_fetch_assoc(mysqli_query($link, "
  		SELECT 
    		`id`, 
      	`url`, 
      	`title`, 
      	`preview`, 
      	`picture`, 
      	`date` 
    	FROM `articles` 
    	WHERE `rubric`='$rubric_data[id]'
    	ORDER BY `date` DESC 
    	LIMIT 1
  	" ));
  
  	$response['article'] = array (
    	  'id' => $article['id'],
     		 'url' => $article['url'],
    	  'title' => $article['title'],
    	  'preview' => $article['preview'],
    	  'picture' => $article['picture'],
    	  'date' => $article['date'],
  	);
  
  	$response['rubricId'] = $rubric_data['id'];
  	$response['rubricLink'] = $rubric_data['link'];
  	$response['rubricTitle'] = $rubric_data['name'];
    
  } else {
    
    $response = false;
    
  }
  

  echo json_encode($response);
  
?>