<?
	/* header('Access-Control-Allow-Origin: *');
     header('Access-Control-Allow-Methods: GET,POST');
     header('Access-Control-Allow-Headers: Content-Type'); */

  require_once './config/connect.php'; // connecting to db and get $link variable from them
    
  $count = 9; // number of popular articles to print

  	
  // receive articles according to the page
  $res_visits = mysqli_query($link, "
    SELECT `id`, `article`, `visits` 
    FROM `visits` 
    ORDER BY `visits` DESC 
    LIMIT " . $count
  );
  

  for($i = 0; $i < mysqli_num_rows($res_visits); $i++) {
    $row = mysqli_fetch_row($res_visits);
    

    $res_article = mysqli_fetch_assoc(mysqli_query($link, "
      SELECT 
        `id`, 
        `url`, 
        `rubric`, 
        `title`, 
        `preview`, 
        `picture` 
      FROM `articles` 
      WHERE `id`=$row[1]
    "));
    
    
    $res_rubric = mysqli_fetch_assoc(mysqli_query($link, "
      SELECT `id`, `link`, `name` 
      FROM `rubrics` 
      WHERE `id`='$res_article[rubric]'
    "));
    

    $results[] = array(
      'id' => $res_article['id'],
      'url' => $res_article['url'],
      'title' => $res_article['title'], 
      'preview' => $res_article['preview'], 
      'picture' => $res_article['picture'],
      'visits' => $row[2],
      'rubric' => array(
        'id' => $res_rubric['id'], 
        'link' => $res_rubric['link'], 
        'name' => $res_rubric['name']
      ), 
    );
  }
  
  $response['results'] = $results;

  echo json_encode($response);
?>