<?
  // shielding variables
  require_once './utils/shielding-variables.php';
  
	shieldingVariables();
  
  // get variables from the POST array
  extract($_GET);
  
  // connecting to db and get $link variable from them
  require_once './config/connect.php';
  
  
	$article = mysqli_fetch_assoc(mysqli_query($link, "
  	SELECT * 
    FROM `articles` 
    WHERE `url`='$url'
  " ));
  
  
  $rubric = mysqli_fetch_assoc(mysqli_query($link, "
  	SELECT * 
    FROM `rubrics` 
    WHERE `id`='$article[rubric]'
  " ));
  $response['rubric'] = array (
      'id' => $rubric['id'],
      'link' => $rubric['link'],
      'name' => $rubric['name']
  );


  $copywriter = mysqli_fetch_assoc(mysqli_query($link, "
  	SELECT *
    FROM `copywriters`
    WHERE `id`='$article[copywriter]'
  " ));
  $response['copywriter'] = array (
      'id' => $copywriter['id'],
      'name' => $copywriter['name'],
      'photo' => $copywriter['photo']
  );


  $author = mysqli_fetch_assoc(mysqli_query($link, "
  	SELECT *
    FROM `authors` 
    WHERE `id`='$article[author]'
  " ));
  $response['author'] = array (
      'id' => $author['id'],
      'name' => $author['name'],
      'photo' => $author['photo']
  );


  $photographer = mysqli_fetch_assoc(mysqli_query($link, "
  	SELECT *
    FROM `photographers` 
    WHERE `id`='$article[photographer]'
  " ));
  $response['photographer'] = array (
      'id' => $photographer['id'],
      'name' => $photographer['name'],
      'photo' => $photographer['photo']
  );


  $stylist = mysqli_fetch_assoc(mysqli_query($link, "
  	SELECT *
    FROM `stylists` 
    WHERE `id`='$article[stylist]'
  " ));
  $response['stylist'] = array (
      'id' => $stylist['id'],
      'name' => $stylist['name'],
      'photo' => $stylist['photo']
  );
  
  
  // date normalizer
  require_once './utils/normalize-date.php';
  $response['date'] = normalize_date($article['date']);


  $response['id'] = $article['id'];
  $response['url'] = $article['url'];
  $response['title'] = $article['title'];
  $response['subtitle'] = $article['subtitle'];
  $response['preview'] = $article['preview'];
  $response['picture'] = $article['picture'];
  $response['keywords'] = $article['keywords'];
  $response['description'] = $article['description'];
  $response['content'] = $article['content'];
  
  
  // If the requested article is not there, rewrite the response to false
  if ($response['id'] === null) {
    $response = false;
  }
  
  echo json_encode($response);
  
  
  // Update the number of article views in the database
  if ($response['id'] !== null) {
  	mysqli_query($link, "
  		UPDATE `visits` 
  		SET `visits`=`visits` + 1 
  		WHERE `article`='$response[id]'
  	" );
  }


?>